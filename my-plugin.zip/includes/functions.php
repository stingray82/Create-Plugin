<?php
if ( ! defined('ABSPATH') ) {
    exit;
}

// Example function (update as needed)
function my_plugin_example_function() {
    return true;
}

/* SureCart / Licensing / Updater */
add_action('init', function(){
    // Load the SureCart Licensing Client if not already loaded.
    if ( ! class_exists('SureCart\Licensing\Client') ) {
        // Adjust the path: since this file is in the "includes" folder, Client.php is in "includes/src"
        require_once __DIR__ . '/src/Client.php';
    }
    
    // Initialize the licensing client with your plugin name and public token.
    $client = new \SureCart\Licensing\Client( 'Your Plugin', 'pt_jzieNYQdE5LMAxksscgU6H4', __FILE__ );
    
    // Set your textdomain.
    $client->set_textdomain('your-textdomain');
    
    // Add the pre-built license settings page.
    $client->settings()->add_page( [
        'type'                 => 'submenu', // Options: menu, options, submenu.
        'parent_slug'          => 'your-plugin-menu-slug', // Replace with your plugin menu slug.
        'page_title'           => 'Manage License',
        'menu_title'           => 'Manage License',
        'capability'           => 'manage_options',
        'menu_slug'            => $client->slug . '-manage-license',
        'icon_url'             => '',
        'position'             => null,
        'parent_slug'          => '', // Update as needed.
        'activated_redirect'   => admin_url('admin.php?page=my-plugin-page'),
        'deactivated_redirect' => admin_url('admin.php?page=my-plugin-deactivation-page'),
    ]);
});

/* WP Update Server */
require_once MY_PLUGIN_DIR . 'plugin-update-checker/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;
$my_plugin_update_checker = PucFactory::buildUpdateChecker(
    'https://example.com/path/to/details.json',
    MY_PLUGIN_MAIN_FILE,
    MY_PLUGIN_SLUG
);
