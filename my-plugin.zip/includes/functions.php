<?php
if (!defined('ABSPATH')) {
    exit;
}

// Example function
function my_plugin_example_function() {
    return
}
