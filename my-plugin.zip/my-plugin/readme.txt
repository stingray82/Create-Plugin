=== My Plugin ===
Contributors: yourname
Tags: example, plugin
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==
A simple WordPress plugin starter template.
